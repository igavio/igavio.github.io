/**
 * Τηρεί τα στοιχεία για τα αγαθά που εκπλειστηριάζονται
 * @version 2.1
 */
public class Lot {

  private final int number;   // Κωδικός αριθμός του αγαθού – δεν αλλάζει
  private String description; // Περιγραφή του αγαθού
  private Bid highestBid;     // Μεγαλύτερη προσφορά για το αγαθό μέχρι στιγμής
  private long minBid = 0;    // Τιμή εκκίνησης για το αγαθό                  Ε2
  
  /**
   * Κατασκευάζει αγαθό με συγκεκριμένο αριθμό, περιγραφή χωρίς τιμή εκκίνησης.
   * @param number Ο κωδικός του αγαθού
   * @param description Η περιγραφή του αγαθού
   */
  public Lot(int number, String description) {
    this.number = number;
    this.description = description;
    this.highestBid = null;
  }

  /**
   * Κατασκευάζει ένα αγαθό με συγκεκριμένο αριθμό, περιγραφή και τιμή εκκίνησης.
   * @param number Ο κωδικός του αγαθού
   * @param description Η περιγραφή του αγαθού
   * @param minBid τιμή εκκίνησης
   */
  public Lot(int number, String description, long minBid) {                 //Ε2
    this(number, description); //κληση του προηγουμενου κατασκευαστη
    this.minBid = minBid;                                  
  }
  
  /**
   * @return Ο κωδικός αριθμός αγαθού
   */
  public int getNumber() {
    return this.number;
  }

  /**
   * @return Η περιγραφή αυτού του αγαθού
   */
  public String getDescription() {
    return this.description;
  }

  /**
   * @return Η καλύτερη προσφορά για αυτό το αγαθό.
   * null αν δεν έχει γίνει καμιά προσφορά.
   */
  public Bid getHighestBid() {
    return this.highestBid;
  }

  /**
   * @return Τα στοιχεία της προσφοράς για εκτύπωση
   */
  public String toString() {
    String details = "ΑΓΑΘΟ" + "\t Κωδικός:" + this.number + 
                               "\t Περιγραφή:" + this.description + 
                               "\t Τιμή εκκίνησης:"  + this.minBid;        //E2
    if (highestBid != null)
      details += "\t Καλύτερη " + highestBid.toString();
    else
      details += "\t (Καμιά προσφορά)";
    return details;
  }

  /**
   * Υποβλήθηκε προσφορά γι αυτό το αγαθό. Δες αν είναι η καλύτερη μέχρι στιγμής.
   * @param bid Η νέα προσφορά
   * @return true εάν εγινε αποδεκτή, false αν απορρίφθηκε
   */
  public boolean bidFor(Bid bid) {
    Person bidder = bid.getBidder(); // αυτος που εκανε την προσφορα
    //  αν η προσφορά που υποβαλλεται, υπερκαλύπτει την τιμή εκκίνησης ΚΑΙ
    if ((bid.getValue() >= this.minBid) &&
        ((highestBid == null) || // δεν έχει υποβληθεί άλλη προσφορά ή
         (highestBid.getValue() < bid.getValue()))) { // έχει υποβληθεί προσφορά
                                                     // αλλά αυτή είναι καλύτερη
        highestBid = bid; // θέσε την ως την καλύτερη προσφορά για το αγαθό
        bidder.incrSuccessfulBids();                                      //E5
        return true;
      } //end if
    bidder.incrFailedBids();
    return false;
  } //end bidFor
} //end class Lot
