import java.util.ArrayList;  // συλλογή
import java.util.Iterator;   // απαριθμητής

/**
 * Ένας πλειστηριασμός περιλαμβάνει αγαθά για τα οποία γίνονται προσφορές.
 * @version 2.1
 */
public class Auction {

  /**
   * Η συλλογή των αγαθών που εκπλειστηριάζονται 
   */
  private ArrayList lots;

  /**
   * Αριθμός που θα δοθεί στο επόμενο αγαθό που θα εισαχθεί  
   */
    private int nextLotNumber;
  
  /**
   * Οι ανθρωποι που συμμετέχουν τον πλειστηριασμό
   */
  private ArrayList persons;                                                //E1


  /**
   * Κατασκευάζει έναν πλειστηριασμό.
   */
  public Auction() {
    lots = new ArrayList(); // αρχικά κανένα αγαθό
    nextLotNumber = 1;  // το επόμενο αγαθό θα πάρει αριθμό 1
    persons = new ArrayList(); // αρχικά κανένας συμμετέχων                 //E1
  }

  /**
   * Εισάγει αγαθό σε αυτόν τον πλειστηριασμό
   * @param description Η περιγραφή του υλικού
   */
  public void enterLot(String description) {
    lots.add(new Lot(nextLotNumber, description)); //βάλε στη συλλογή
    nextLotNumber++; // ενημέρωση μετρητή
  }
  /**
   * Εισάγει αγαθό σε αυτόν τον πλειστηριασμό
   * @param description Η περιγραφή του υλικού
   * @param minBid Τιμή εκκίνησης για το αγαθό                                Ε2
   */
  public void enterLot(String description, long minBid) {                   //Ε2
    lots.add(new Lot(nextLotNumber, description, minBid)); //βάλε στη συλλογή
    nextLotNumber++; // ενημέρωση μετρητή
  }

  /**
   * Εισάγει άνθρωπο σε αυτόν τον πλειστηριασμό
   * @param name Το όνομα του ανθρώπου
   */
  public void enterPerson(String name) {                                    //E1
    persons.add(new Person(name)); // εισαγωγή στη συλλογή
  }
  
  /**
   * Επιστρέφει τον άνθρωπο με συγκεκριμένο αριθμό
   * @param personNumber 0 έως πλήθος - 1 
   * @return τον αντίστοιχο άνθρωπο 
   */
  public Person getPerson(int personNumber) {
    if ((personNumber >=0) && (personNumber < persons.size()))
      return (Person) persons.get(personNumber);
    else {
      System.err.println("Δεν υπάρχει άνθρωπος με αριθμό " + personNumber);
      return null;      
    } //end else
  }

  /**
   * Επιστρέφει την προσφορά με συγκεκριμένο αριθμό ή null αν δεν υπάρχει.
   * @param lotNumber Ο αριθμός της προσφοράς
   */
  public Lot getLot(int lotNumber) {
    if ((lotNumber >= 1) && (lotNumber < nextLotNumber))  //υπάρχει το αγαθό
      return (Lot) lots.get(lotNumber - 1); // στην προηγούμενη θέση
    else {
      System.err.println("Δεν υπάρχει αγαθό με αριθμό " + lotNumber);
      return null;
    } //end else
  }

  /**
   * Επιστρέφει όλα τα αγαθά αυτού του πλειστηριασμού
   */
  public String showLots() {
    String result = "";
    Iterator it = lots.iterator();
    while (it.hasNext()) {
      Lot lot = (Lot) it.next();
      result += lot.toString() + "\n";
    } // end while
    return result;
  }

  /**
   * Δημιουργεί προσφορά. Εμφανίζει μήνυμα όταν είναι επιτυχής ή όχι.
   * @param number Ο αριθμός του αγαθού για το οποίο γίνεται η προσφορά
   * @param bidder Ο άνθρωπος που κάνει την προσφορά
   * @param value Η αξία της προσφοράς
   */
  public void bidFor(int lotNumber, Person bidder, long value) {
    Lot selectedLot = getLot(lotNumber); // ανακάλεσε την προσφορά για το υλικό
    if (selectedLot != null) // δεν έχει υποβληθεί προσφορά
      if (selectedLot.bidFor(new Bid(bidder, value))) 
        System.out.println("Επιτυχής προσφορά για το " + lotNumber);
      else
        System.out.println("Προσφορά απορρίφθηκε για το " + lotNumber);
  } //end bidFor
 
  public void close() {                                                     //E3
    showLots();
  }
  
  /**
   * Επιστρέφει τις επιτυχημένες προσφορές που έχει κάνει συγκεκριμένος άνθρωπος.
   * @param pname το όνομα του ανθρώπου
   * @return τα στοιχεία του ανθρώπου και των επιτυχημένων προσφορών του
   */
  public String bidSuccessfully(String pname) {                             //Ε4
    String result ="Επιτυχημένες προσφορές του " + pname + ":\n";
    Iterator it = lots.iterator();
    while (it.hasNext()) { //για κάθε αγαθό
      Lot lot = (Lot) it.next();
      Bid maxBid = lot.getHighestBid(); 
      if (maxBid != null) { //αν εχει γίνει προσφορά για αυτό το αγαθό
        Person bidder = maxBid.getBidder(); //βρες ποιος την έκανε
        if (bidder.getName().equals(pname)) //και αν ειναι αυτού που ψάχνεις
          result += lot + "\n"; //φύλαξέ την
      }
    } // end while
    return result;
  }
  
  /**
   * @return Επιστρέφει στοιχεία για τη συμμετοχή
   */
  public String personsAndBids() {
    String result = ""; 
    int num = 0;
    Iterator it = persons.iterator();
    while (it.hasNext()) {
      Person person = (Person) it.next();
      result += num + " \t" + person.toString() + "\n" +
                bidSuccessfully(person.getName()) + "\n";
      num ++;
    } // end while
    return result;    
  }
} //end class Auction
