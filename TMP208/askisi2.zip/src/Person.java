
/**
 * Τηρεί τα στοιχεία ανθρώπου που συμμετέχει σε πλειστηριασμό
 * @version 2.1
 */
public class Person {

  /**
   * Το όνομα του ανθρώπου
   */
  private final String name;

  /**
   * Πλήθος επιτυχημένων προσφορών που έχει υποβάλει. Αρχικά μηδέν.
   */
  private long successfulBids = 0;                                          //E5
  
  /**
   * Πλήθος αποτυχημένων προσφορών που έχει υποβάλει. Αρχικά μηδέν.
   */
  private long failedBids = 0;                                              //E5
  
  /**
   * Κατασκευάζει άνθρωπο με συγκεκριμένο όνομα.
   * @param name Το όνομα του ανθρώπου
   */
  public Person(String name) {
    this.name = name; // το this διακρίνει την ιδιότητα από την ομώνυμη παράμετρο
  }

  /**
   * @return Το όνομα αυτού του ανθρώπου
   */
  public String getName() {
    return this.name;
  }
  
  /**
   * Αυξάνει κατά ένα το πλήθος των επιτυχημένων προσφορών που έχει υποβάλει.
   */
  public void incrSuccessfulBids() {                                        //E5
    successfulBids ++;
  }

  /**
   * Αυξάνει κατά ένα το πλήθος των αποτυχημένων προσφορών που έχει υποβάλει.
   */
  public void incrFailedBids() {                                            //E5
    failedBids ++;
  }
  
  public String toString() {
    return "ΑΝΘΡΩΠΟΣ" + "\t Ονομα:" + this.name + 
                        "\t Επιτυχείς: " + this.successfulBids + 
                        "\t Αποτυχημένες: " + this.failedBids;
  }
} //end class Person
