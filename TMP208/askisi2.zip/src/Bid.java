
/**
 * Κλάση για προσφορές επί αγαθών ενός πλειστηριασμού
 * @version 2.1
 */
public class Bid {

  /**
   * Ο άνθρωπος που κάνει την προσφορά
   */
  private final Person bidder;
  
  /**
   * Η αξία της προσφοράς
   */
  private final long value;

  /**
   * Κατασκευάζει μια προσφορά.
   * @param bidder Ο άνθρωπος που κάνει αυτή την προσφορά
   * @param value Η αξία αυτής της προσφοράς
   */
  public Bid(Person bidder, long value) {
    this.bidder = bidder;
    this.value = value;
  }

  /**
   * @return Ο άνθρωπος που κάνει αυτή την προσφορά
   */
  public Person getBidder() {
    return this.bidder;
  }

  /**
   * @return Η αξία αυτής της προσφοράς
   */
  public long getValue() {
    return this.value;
  }
  
  public String toString() {
    return "ΠΡΟΣΦΟΡΑ" + "\t Αγοραστής:" + this.bidder.getName() + "\t Αξία:" + this.value; 
  }
} //end class Bid
