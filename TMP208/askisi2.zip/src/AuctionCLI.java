import javax.swing.JOptionPane;

/**
 * Command Line Interface για τον πλειστηριασμό
 * @version 2.1
 */
public class AuctionCLI {

  public static void main(String[] args) {

    Auction myAuction = new Auction();

    System.out.println("ΞΕΚΙΝΑ Ο ΠΛΕΙΣΤΗΡΙΑΣΜΟΣ");
    myAuction.enterLot("Πορτα", 9); //αρ. 1
    myAuction.enterLot("Τζαμι", 0); //αρ. 2
    myAuction.enterPerson("Κωστας"); //αρ. 0
    myAuction.enterPerson("Πετρος"); //αρ. 1
    myAuction.enterPerson("Μαριτα"); //αρ. 2
    
    myAuction.bidFor(1, myAuction.getPerson(0),  7); //Κωστας προσφερει  7 για πορτα ΑΠΟΡΡΙΠΤΕΤΑΙ
    myAuction.bidFor(2, myAuction.getPerson(1),  5); //Πετρος προσφερει  5 για τζαμι ΔΕΚΤΗ
    myAuction.bidFor(1, myAuction.getPerson(2), 13); //Μαριτα προσφερει 13 για πορτα ΔΕΚΤΗ
    myAuction.bidFor(1, myAuction.getPerson(2),  6); //Μαριτα προσφερει  6 για πορτα ΑΠΟΡΡΙΠΤΕΤΑΙ
    
    System.out.println("ΤΕΛΕΙΩΝΕΙ Ο ΠΛΕΙΣΤΗΡΙΑΣΜΟΣ");
    myAuction.close();                                                      //Ε3
    System.out.println(myAuction.bidSuccessfully("Πετρος"));                //Ε4
    
    System.out.println(myAuction.personsAndBids());                         //Ε5
    System.out.println("-----------------------------------------------------");
    commandLineInterface(myAuction);
  }

  public static void commandLineInterface(Auction myAuction) {
    Object[] epiloges = new Object[6]; //επιλογές λειτουργιών
    epiloges[0] = "Νέος άνθρωπος";         
    epiloges[1] = "Νέο αγαθό";
    epiloges[2] = "Προσφορά ανθρώπου για αγαθό";
    epiloges[3] = "Στατιστικά αγαθών";
    epiloges[4] = "Στατιστικά ανθρώπων";
    epiloges[5] = "Τερματισμός";
    Object epilogi;					//arxikopoiei ena Object

    boolean finish = false;
    while (! finish) //to parathiro auto tha emfanizetai mexri o finish na ginei false
    {
      epilogi = JOptionPane.showInputDialog(null, "Επέλεξε λειτουργία:",
              "Βασική επιλογή", JOptionPane.INFORMATION_MESSAGE, null,
              epiloges, epiloges[0]);
      if (epilogi.equals(null)) {
        //do nothing
      }
      else if (epilogi.equals(epiloges[0])) {
        String name = JOptionPane.showInputDialog("Δώσε όνομα ανθρώπου:");
        myAuction.enterPerson(name);
      }
      else if (epilogi.equals(epiloges[1])) {
        String descr = JOptionPane.showInputDialog("Δώσε περιγραφή αντικειμένου:)");
        String value = JOptionPane.showInputDialog("Δώσε τιμή εκκίνησης:");
        myAuction.enterLot(descr, Long.parseLong(value));
      }
      else if (epilogi.equals(epiloges[2])) {
        String agatho = JOptionPane.showInputDialog(null, 
                "Δώσε αριθμό του αγαθού για το οποίο υποβάλεις προσφορά");
        int numAgathou = Integer.parseInt(agatho);

        String person = JOptionPane.showInputDialog(null, 
                "Δώσε αριθμό του ανθρώπου που υποβάλει την προσφορά");
        int numPerson = Integer.parseInt(person);

        String timi = JOptionPane.showInputDialog("Τι τιμή προσφέρει;");
        long longTimi = Long.parseLong(timi);
        
        myAuction.bidFor(numAgathou, myAuction.getPerson(numPerson), longTimi);
      }
      else if (epilogi.equals(epiloges[3])) {
        System.out.println(myAuction.showLots());    
      }
      else if (epilogi.equals(epiloges[4])) {
        System.out.println(myAuction.personsAndBids());    
      }
      else if (epilogi.equals(epiloges[5])) {
        myAuction.close();
        System.exit(0);
      }
    }
  }
}
