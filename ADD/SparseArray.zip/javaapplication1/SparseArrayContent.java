package javaapplication1;

/**
 * Δομη για καθε στοιχειο του αραιου πινακα.
 * Κραταμε γραμμη, στηλη και τιμη
 */
public class SparseArrayContent {

    int row;
    int col;
    double value;

    SparseArrayContent() {
    }

    SparseArrayContent(int row, int col, double value) {
        this.row = row;
        this.col = col;
        this.value = value;
    }
}