package javaapplication1;

import java.util.Random; // για τη γεννητρια τυχαιων αριθμων

import java.util.Vector; // για τον πινακα δυναμικου μεγεθους

public class SparseArray {

    private Vector sparseArray; // τα περιεχομενα του πινακα μπαινουν εδω
    public static final int MAX_ROW = 20; // αριθμος γραμμων του πινακα
    public static final int MAX_COL = 20; // αριθμος στηλων του πινακα

    public SparseArray() {
        sparseArray = new Vector();
    }

    public int getNoOfElements() {
        return sparseArray.size();
    }

    /**
     * Επιστρέφει το περιεχομενο που βρισκεται σε μια θεση του διανυμσατος
     * @param inPosition η θεση του διανυσματος
     * @return ενα στοιχειο του αραιου πινακα
     */
    public SparseArrayContent getElement(int inPosition) {
        if ((inPosition >= 0) && (inPosition < this.getNoOfElements())) {
            return ((SparseArrayContent) sparseArray.get(inPosition));
        } else {
            return null;
        }
    }

    /**
     * Βρισκει αν υπαρχει τιμη για συγκεκριμενη θεση του αραιου πινακα
     * @param row η γραμμη του αραιου πινακα
     * @param col η στηλη του αραιου πινακα
     * @return αληθες αν εχει τιμη στη θεση αυτη, ψευδες αν ειναι κενη
     */
    public boolean isIn(int row, int col) {
        SparseArrayContent temp = new SparseArrayContent();
        for (int i = 0; i < this.getNoOfElements(); i++) {
            temp = (SparseArrayContent) sparseArray.get(i);
            if ((temp.row == row) && (temp.col == col)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Επιστρεφει την τιμη σε συγκεκριμενη θεση του αραιου πινακα, αλλιως -1
     * @param row η γραμμη του αραιου πινακα
     * @param col η στηλη του αραιου πινακα
     * @return η τιμη του περιεχομενου της θεσης του αραιου πινακα
     */
    public double get(int row, int col) {
        SparseArrayContent temp = new SparseArrayContent();
        for (int i = 0; i < sparseArray.size(); i++) {
            temp = (SparseArrayContent) sparseArray.get(i);
            if ((temp.row == row) && (temp.col == col)) {
                return temp.value;
            }
        }
        return -1.0;
    }

    /**
     * Ενημερωνει τον αραιο πινακα με μια τιμη σε συγκεκριμενη θεση
     * @param row η γραμμη του αραιου πινακα
     * @param col η στηλη του αραιου πινακα
     * @param value η τιμη του περιεχομενου της θεσης του αραιου πινακα
     */
    public void set(int row, int col, double value) {
        SparseArrayContent temp = new SparseArrayContent();
        for (int i = 0; i < sparseArray.size(); i++) {
            temp = (SparseArrayContent) sparseArray.get(i);
            if ((temp.row == row) && (temp.col == col)) {
                ((SparseArrayContent) sparseArray.get(i)).value = value;
                return;
            }
        }
        sparseArray.add(new SparseArrayContent(row, col, value));
    }

    public static void main(String[] args) {
        final int SIZE = 20;
        SparseArray s = new SparseArray();

        do {
            s.set(randomGenerator.nextInt(MAX_ROW),
                    randomGenerator.nextInt(MAX_COL),
                    randomGenerator.nextDouble());
        } while (s.getNoOfElements() < SIZE);

        for (int i = 0; i < SIZE; i++) {
            SparseArrayContent temp = s.getElement(i);
            System.out.println("Pos=" + i +
                    "\tRow=" + temp.row +
                    "\tCol=" + temp.col +
                    "\tValue=" + temp.value);
        }
    }
    /**************************************************************************/
    private static Random randomGenerator = new Random();

    /**
     * @param n ακέραιος που ορίζει το εύρος των τυχαίων αριθμών
     * @return τυχαίο ακέραιο σε εύρος -n..0..n  διάστημα [-n, +n]
     */
    public static int myRandom(int n) {
        return randomGenerator.nextInt(2 * n + 1) - n;
    }
}

