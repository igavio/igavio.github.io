package bt;

/**
 * Αποθηκεύει δυαδικό δέντρο σε πίνακα
 * @author igavio
 */
public class BinTree {

  /**
   * Οι διαθέσιμες θέσεις για την τοποθέτηση των κόμβων του δέντρου
   * είναι 1 (για τη ρίζα) ως MAX_SIZE-1
   */
  public static final int MAX_SIZE = 32;
  /**
   * Η τιμή που είναι αποθηκευμενη στον πίνακα και
   * υποδηλώνει ότι εκεί δεν υπάρχει κόμβος του δέντρου.
   */
  public static final String EMPTY_NODE = "";
  private int size;
  private String bt[];

  /**
   * Κατασκευάζει ένα κενό δυαδικό δέντρο.
   */
  public BinTree() {
    bt = new String[MAX_SIZE];
    for (int position = 1; position < MAX_SIZE; position++) {
      bt[position] = EMPTY_NODE; //αρχικοποιεί τα περιεχόμενα των κόμβων
    }
    size = 0;
  }

  /**
   * Επιστρέφει το μέγεθος του δέντρου
   * @return 0 αν είναι άδειο, διαφορετικά ένα θετικό ακέραιο που είναι το πλήθος των κόμβων
   */
  public int size(){
    return size;
  }

  /**
   * Προσθέτει ένα κόμβο στο δέντρο, εφόσον χωράει στο διαθέσιμο χώρο και
   * κρεμιέται σε θέση που έχει γονέα.
   * Αν υπάρχει ήδη αυτός ο κόμβος, απλώς του αλλάζει το περιεχόμενο.
   * @param position η θέση στην οποία θα προστεθεί ο νέος κόμβος
   * @param content το περιεχόμενο του νέου κόμβου
   * @return αληθές αν προστέθηκε επιτυχώς, ψευδές διαφορετικά
   */
  public boolean insert(int position, String content) {
    if ((position < 1) || (position >= MAX_SIZE)) { //εκτός ορίων
      System.err.println("Εισαγωγή στο " + position + "απέτυχε: θέση εκτός αποδεκτών ορίων");
      return false;
    } else if (position == 1) { //στη ρίζα
      if (isEmpty(position)) {
        size++;
      }
      bt[position] = content;
      System.err.println("Εισαγωγή του " + content + " στη ρίζα");
      return true;
    } else { //σε έγκυρη θέση του πίνακα
      if (bt[parent(position)] == null) {
        System.err.println("Εισαγωγή στο " + position + "απέτυχε: δεν υπάρχει γονικός κόμβος.");
        return false;
      } else {
        if (isEmpty(position)) {
          size++;
        }
        bt[position] = content;
        System.err.println("Εισαγωγή του " + content + " στη θέση " + position);
        return true;
      }
    }
  }

  /**
   * Ελέγχει αν σε μια θέση του πίνακα είναι άδεια.
   * @param position Η θέση που ελέγχει
   * @return Αληθές αν είναι κενή, ψευδές διαφορετικά
   */
  public boolean isEmpty(int position) {
    return (bt[position].equals(EMPTY_NODE));
  }

  /**
   * Επιστρέφει το γονικό κόμβο.
   * @param position Η θέση του κόμβου για τον οποίο θέλουμε το γονιό
   * @return Η θέση του γονέα του, εφόσον υπάρχει. 0 διαφορετικά
   */
  public int parent(int position) {
    if (position > 1 && position < MAX_SIZE) {
      return position / 2;
    } else {
      //System.err.println("Γονέας δεν υπάρχει: ή δόθηκε ακατάλληλη θέση ή ήταν η ρίζα.");
      return 0; //δεν υπάρχει γονικός κόμβος
    }
  }

  public int left(int position) {
    int leftPosition = 2 * position;
    if (leftPosition >= MAX_SIZE) {
      //System.err.println("Αριστερό παιδί δεν υπάρχει: υπέρβαση μεγέθους δέντρου.");
      return 0;
    } else if (bt[leftPosition].equals("")) {
      //System.err.println("Αριστερό παιδί δεν υπάρχει: ο κόμβος είναι φύλλο.");
      return 0;
    } else {
      return leftPosition;
    }
  }

  public int right(int position) {
    int rightPosition = 2 * position + 1;
    if (rightPosition >= MAX_SIZE) {
      //System.err.println("Δεξί παιδί δεν υπάρχει: υπέρβαση μεγέθους δέντρου.");
      return 0;
    } else if (bt[rightPosition].equals("")) {
      //System.err.println("Δεξί παιδί δεν υπάρχει: ο κόμβος είναι φύλλο.");
      return 0;
    } else {
      return rightPosition;
    }
  }

  public void traverseInOrder(int position) {
    if (position != 0) {
      traverseInOrder(left(position));
      System.out.println("Εσωδιάταξη: Θέση " + position + " Περιεχόμενο " + bt[position]);
      traverseInOrder(right(position));
    }
  }
}
