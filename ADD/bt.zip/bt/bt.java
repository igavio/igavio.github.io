package bt;
public class bt {

    public static void main(String[] args) {
        BinTree myTree = new BinTree();
        myTree.insert(1, "Τ");
        myTree.insert(3, "Ψ");
        System.out.println(myTree.MAX_SIZE);
        myTree.insert(2, "Β");
        myTree.insert(4, "Κ");
        myTree.traverseInOrder(1);
    }

}
