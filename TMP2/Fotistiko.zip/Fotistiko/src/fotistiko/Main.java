package fotistiko;

import java.io.*;

/**
 * Πρόγραμμα ελέγχου ενός φωτιστικού
 * @author igavio
 * @version 2009-04-29
 */
public class Main {

  public static void main(String[] args) throws IOException {
   

    BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
    String sEpilogi;
    int iEpilogi;
    boolean trexei = true;

    do {
      System.out.print("Επιλογές: >");
      System.out.flush(); // για να εμφανιστεί ο δρομέας
      sEpilogi = stdin.readLine();
      iEpilogi = Integer.parseInt(sEpilogi);

      switch (iEpilogi) { // κωδικός διαταγής που δόθηκε
        case 1:

          break;

        case 2:

          break;

        case 0: //τερματισμός
          trexei = false;
          break;

        default:
          System.out.println("Άγνωστη επιλογή");
      }

    } while (trexei);
    System.exit(0);
  }
}
