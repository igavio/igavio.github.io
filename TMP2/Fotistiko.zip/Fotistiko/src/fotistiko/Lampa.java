package fotistiko;

/**
 * Διαχειρίζεται λάμπες που έχουν συγκεκριμένη κατανάλωση και αναβοσβήνουν.
 * @author igavio
 * @version 2009-04-29
 */
public class Lampa {

  /**
   * σταθερές για την κατάσταση της λάμπας
   */
  private static final boolean ANAMMENH = true;
  private static final boolean SBHSTH = false;
  /**
   * η κατάσταση της λάμπας: αν είναι αναμμένη ή σβηστή
   */
  private boolean status;
  /**
   * πόσα watt καιει οταν ειναι αναμμενη;
   */
  private int watt;

  /**
   * Φτιάχνει σβηστή λάμπα συγκεκριμένης κατανάλωσης.
   * @param katanalosi η κατανάλωση της λάμπας σε watt
   */
  public Lampa(int watt) {
    this.watt = watt;
  }

  /**
   * Ανάβει τη λάμπα.
   */
  public void anapse() {
    this.status = ANAMMENH;
  }

  /**
   * Σβήνει τη λάμπα.
   */
  public void svise() {
    this.status = SBHSTH;
  }

  /**
   * Αλλάζει την κατάσταση της λάμπας.
   */
  public void allakse() {
    status = !status;
  }

  /**
   * Επιστρέφει την κατανάλωση της λάμπας ανάλογα με το αν είναι αναμμένη ή σβηστή.
   * @return
   */
  public int getKatanalosi() {
    return status ? watt : 0;
  }

  @Override
  public String toString() {
    return "Κατάσταση:  " + (this.status ? "Αναμμένη" : "Σβηστή") + "\n" +
            "Watt:       " + this.watt + "\n" +
            "Κατανάλωση: " + this.getKatanalosi();

  }
}
