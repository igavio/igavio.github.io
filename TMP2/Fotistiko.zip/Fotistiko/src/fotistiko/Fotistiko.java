package fotistiko;

import java.util.ArrayList;

/**
 * Το φωτιστικό είναι μια συλλογή από ομοειδείς λάμπες
 * @author igavio
 * @version 2009-04-29
 */
public class Fotistiko {

  /**
   * η συλλογή που διατηρεί τις λάμπες
   */
  private ArrayList lampes;

  /**
   * Κατασκευάζει φωτιστικό που έχει πολλές λάμπες συγκεκριμένης κατανάλωσης.
   * @param numOfLampes το πλήθος των λαμπτήρων του φωτιστικού
   * @param katanalosi η κατανάλωση για καθεμιά από τις λάμπες
   */
  public Fotistiko(int numOfLampes, int katanalosi) {
    lampes = new ArrayList(); // άδεια συλλογή
    for (int i = 0; i < numOfLampes; i++) {
      lampes.add(new Lampa(katanalosi)); //προσθήκη στη συλλογή των λαμπτήρων
    }
  }

  /**
   * Σβήνει μια λάμπα του φωτιστικού.
   * @param mia ο αριθμός της λάμπας που θα σβήσει (0 ως αρ. λαμπ. - 1)
   */
  public void svise(int mia) {
    if (mia >= 0 && mia < lampes.size()) {
      Lampa miaLampa = (Lampa) lampes.get(mia);
      miaLampa.svise();
    }
  }

  /**
   * Ανάβει μια λάμπα του φωτιστικού.
   * @param mia ο αριθμός της λάμπας που θα ανάψει (0 ως αρ. λαμπ. - 1)
   */
  public void anapse(int mia) {
    if (mia >= 0 && mia < lampes.size()) {
      Lampa miaLampa = (Lampa) lampes.get(mia);
      miaLampa.anapse();
    }
  }

  /**
   * Σβήνει όλες τις λάμπες του φωτιστικού.
   */
  public void svise() {
    for (int i = 0; i < lampes.size(); i++) {
      Lampa miaLampa = (Lampa) lampes.get(i);
      miaLampa.svise();
    }
  }

  /**
   * Ανάβει όλες τις λάμπες του φωτιστικού.
   */
  public void anapse() {
    for (int i = 0; i < lampes.size(); i++) {
      ((Lampa) lampes.get(i)).anapse();
    }
  }

  /**
   * Τυπώνει την κατάσταση των λαμπτήρων του φωτιστικού και
   * τη συνολική κατανάλωσή του.
   * @return η κατάσταση του φωτιστικού
   */
  @Override
  public String toString() {
    int katanalosi = 0;
    String temp = "Πλήθος λαμπτήρων: " + lampes.size() + "\n";
    for (int i = 0; i < lampes.size(); i++) {
      Lampa miaLampa= (Lampa) lampes.get(i);
      temp += "Λάμπα " + i + "\n" + miaLampa.toString() + "\n";
      katanalosi += miaLampa.getKatanalosi();
    }
    return temp + "Κατανάλωση πολύφωτου: " + katanalosi;
  }
}
